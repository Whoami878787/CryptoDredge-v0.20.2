echo -e '\033]2;MTP (XZC) - 2miners pool\007'
./CryptoDredge -a mtp -o stratum+tcp://xzc.2miners.com:8080 -u a2VcGTRJ8g5NAWQ1pxYUcUVyHpWA2k9BEx -p x
printf "Press <ENTER> to continue..."
read -r continueKey
