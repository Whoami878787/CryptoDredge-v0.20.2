echo -e '\033]2;X16R (RVN) - suprnova pool\007'
./CryptoDredge -a x16r -o stratum+tcp://rvn.suprnova.cc:6667 -u CryptoDredge.benchmark -p x
printf "Press <ENTER> to continue..."
read -r continueKey
