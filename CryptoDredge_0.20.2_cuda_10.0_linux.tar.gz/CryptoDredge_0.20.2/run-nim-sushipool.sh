echo -e '\033]2;Argon2d (NIM) - sushipool pool\007'
./CryptoDredge -a argon2d-nim -o wss://us.sushipool.com:443 -u "NQ68 XM08 9BE8 57DE QMT6 PAT5 PJGQ TEBX FSBU" -p "My Miner"
printf "Press <ENTER> to continue..."
read -r continueKey
