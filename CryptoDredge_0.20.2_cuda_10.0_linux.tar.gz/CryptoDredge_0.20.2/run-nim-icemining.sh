echo -e '\033]2;Argon2d (NIM) - icemining pool\007'
./CryptoDredge -a argon2d-nim -o wss://nimiq.icemining.ca:2053 -u NQ68XM089BE857DEQMT6PAT5PJGQTEBXFSBU -p x
printf "Press <ENTER> to continue..."
read -r continueKey
